import os

LOG_FILE = os.path.join("data", "conversation_log.txt")

def log_conversation(question: str, answer: str):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"用户: {question}\nAI: {answer}\n\n")
