import os
from openai import OpenAI
from dotenv import load_dotenv
from .utils import log_conversation

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

class AIAgent:
    def __init__(self):
        self.client = OpenAI(api_key=api_key)

    def ask(self, question: str) -> str:
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role": "user", "content": question}],
                temperature=0.7
            )
            answer = response.choices[0].message.content.strip()
            log_conversation(question, answer)
            return answer
        except Exception as e:
            return f"出错了: {e}"
