# AI Agent MVP

这是一个简单的本地 Python AI Agent，支持终端问答交互。

## 安装依赖
```
pip install -r requirements.txt
```

## 设置 API Key
在项目根目录创建 `.env` 文件，添加：
```
OPENAI_API_KEY=你的OpenAI_API_Key
```

## 运行
```
python main.py
```
