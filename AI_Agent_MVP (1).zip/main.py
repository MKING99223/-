from agent.agent_core import AIAgent

def main():
    agent = AIAgent()
    print("欢迎使用 AI Agent。输入 'exit' 结束对话。")
    while True:
        user_input = input("你: ")
        if user_input.lower() in ["exit", "quit"]:
            print("AI Agent: 再见！")
            break
        response = agent.ask(user_input)
        print(f"AI Agent: {response}")

if __name__ == "__main__":
    main()
